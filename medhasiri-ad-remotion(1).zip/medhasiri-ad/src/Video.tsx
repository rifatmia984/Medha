import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {fontFamily} from './font';
import {C, SCENES} from './config';
import {Wipe} from './ui';
import {Scene1, Scene2, Scene3} from './scenes/Scenes1to3';
import {Scene4, Scene5, Scene6, Scene7} from './scenes/Scenes4to7';

const MAP = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6, Scene7];
const WIPE = [C.blue, C.blue, C.orange, C.green, C.blue, C.orange, C.navy];

export const Video: React.FC = () => (
  <AbsoluteFill style={{fontFamily, backgroundColor: '#fff'}}>
    <Audio src={staticFile('voice.mp3')} />
    {SCENES.map((s, i) => {
      const Comp = MAP[i];
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.dur}>
          <Comp />
          {i > 0 ? <Wipe color={WIPE[i]} /> : null}
        </Sequence>
      );
    })}
  </AbsoluteFill>
);
