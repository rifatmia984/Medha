import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {C} from './config';

export type Expr = 'neutral' | 'happy' | 'excited' | 'worried' | 'thinking' | 'proud';
export type Hair = 'short' | 'bun' | 'pigtails' | 'none';

type P = {
  x: number; y: number; scale?: number; delay?: number; seed?: number;
  skin?: string; hair?: string; hairStyle?: Hair; top?: string; bottom?: string; shoes?: string;
  orna?: string; glasses?: boolean; kid?: boolean; collar?: boolean; tie?: string; medal?: boolean; bag?: string;
  expr?: Expr; armL?: number; armR?: number; waveL?: number; waveR?: number;
  propR?: React.ReactNode; propL?: React.ReactNode; jump?: boolean; tremble?: boolean;
};

const BROWS: Record<Expr, number[][]> = {
  neutral: [[-26, -297, -8, -297], [8, -297, 26, -297]],
  happy: [[-26, -300, -8, -302], [8, -302, 26, -300]],
  excited: [[-26, -303, -8, -306], [8, -306, 26, -303]],
  worried: [[-26, -291, -8, -301], [8, -301, 26, -291]],
  thinking: [[-26, -297, -8, -299], [8, -306, 26, -300]],
  proud: [[-26, -300, -8, -302], [8, -302, 26, -300]],
};

/** সরল ফ্ল্যাট কার্টুন ক্যারেক্টার (পা মাটিতে, x/y = পায়ের মাঝখান) */
export const Character: React.FC<P> = ({
  x, y, scale = 2, delay = 0, seed = 0, skin = '#f2c29b', hair = '#2b1b12', hairStyle = 'short',
  top = '#4caf50', bottom = '#37474f', shoes = '#222', orna, glasses, kid, collar, tie, medal, bag,
  expr = 'neutral', armL = 8, armR = 8, waveL = 0, waveR = 0, propR, propL, jump, tremble,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const f = frame - delay;
  if (f < 0) return null;
  const pop = spring({frame: f, fps, config: {damping: 11, stiffness: 120, mass: 0.7}});
  const float = Math.sin((frame + seed * 17) / 14) * 4;
  const hop = jump ? -Math.abs(Math.sin((frame + seed * 9) / 7)) * 34 : 0;
  const shake = tremble ? Math.sin(frame * 2.3) * 3 : 0;
  const eyeY = (frame + seed * 23) % 96 < 4 ? 0.1 : 1;
  const aL = armL + Math.sin((frame + seed * 5) / 4) * waveL;
  const aR = armR + Math.sin((frame + seed * 5) / 4 + 1.6) * waveR;
  const k = kid ? 0.64 : 1;
  const S = {stroke: C.ink, strokeWidth: 2.6, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
  const br = BROWS[expr];

  const eyes = expr === 'proud' ? (
    <g fill="none" stroke={C.ink} strokeWidth={3} strokeLinecap="round">
      <path d="M-24 -278 Q-16 -290 -8 -278" /><path d="M8 -278 Q16 -290 24 -278" />
    </g>
  ) : (
    <g fill={C.ink}>
      <ellipse cx={-16} cy={-280} rx={5.5} ry={7.5 * eyeY} />
      <ellipse cx={16} cy={-280} rx={5.5} ry={7.5 * eyeY} />
      {expr === 'excited' ? (<><circle cx={-14} cy={-283} r={2} fill="#fff" /><circle cx={18} cy={-283} r={2} fill="#fff" /></>) : null}
    </g>
  );

  const mouth =
    expr === 'happy' ? <path d="M-14 -258 Q0 -241 14 -258" fill="none" {...S} />
    : expr === 'excited' ? <path d="M-15 -260 Q0 -230 15 -260Z" fill="#9b1c1c" {...S} />
    : expr === 'proud' ? <path d="M-15 -259 Q0 -236 15 -259Z" fill="#fff" {...S} />
    : expr === 'worried' ? <path d="M-10 -250 Q0 -260 10 -250" fill="none" {...S} />
    : expr === 'thinking' ? <path d="M-8 -252 Q3 -256 11 -254" fill="none" {...S} />
    : <path d="M-9 -255 L9 -255" fill="none" {...S} />;

  const hairBack = hairStyle === 'bun' ? <circle cx={0} cy={-344} r={20} fill={hair} {...S} /> : null;
  const hairFront = hairStyle === 'none' ? null : (
    <>
      <path d="M-46 -282 Q-52 -334 0 -334 Q52 -334 46 -282 Q30 -312 0 -308 Q-30 -312 -46 -282Z" fill={hair} {...S} />
      {hairStyle === 'pigtails' ? (<><circle cx={-58} cy={-286} r={16} fill={hair} {...S} /><circle cx={58} cy={-286} r={16} fill={hair} {...S} /></>) : null}
    </>
  );

  return (
    <svg style={{position: 'absolute', left: 0, top: 0, width: '100%', height: '100%', overflow: 'visible'}}
      viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid slice">
      <ellipse cx={x} cy={y + 6} rx={75 * scale * k * Math.min(pop, 1)} ry={12 * scale * k} fill="rgba(0,0,0,.14)" />
      <g transform={`translate(${x + shake},${y + float * 0.5 + hop}) scale(${scale * k * pop})`}>
        {bag ? <rect x={-54} y={-208} width={28} height={92} rx={12} fill={bag} {...S} /> : null}
        {/* পা ও জুতা */}
        <rect x={-24} y={-118} width={19} height={108} rx={9.5} fill={bottom} {...S} />
        <rect x={5} y={-118} width={19} height={108} rx={9.5} fill={bottom} {...S} />
        <ellipse cx={-17} cy={-8} rx={19} ry={9} fill={shoes} {...S} />
        <ellipse cx={17} cy={-8} rx={19} ry={9} fill={shoes} {...S} />
        {/* শরীর */}
        <rect x={-42} y={-232} width={84} height={128} rx={30} fill={top} {...S} />
        {collar ? <path d="M-18 -232 L0 -208 L18 -232Z" fill="#fff" {...S} /> : null}
        {tie ? <path d="M0 -222 L-9 -204 L0 -166 L9 -204Z" fill={tie} {...S} /> : null}
        {medal ? (
          <g>
            <path d="M-12 -230 L0 -190 L12 -230" fill={C.red} {...S} />
            <circle cx={0} cy={-184} r={14} fill={C.yellow} {...S} />
          </g>
        ) : null}
        {/* হাত */}
        <g transform={`translate(-42,-214) rotate(${aL})`}>
          <rect x={-9} y={-6} width={18} height={84} rx={9} fill={top} {...S} />
          <circle cx={0} cy={84} r={11} fill={skin} {...S} />
          {propL ? <g transform="translate(0,84)">{propL}</g> : null}
        </g>
        <g transform={`translate(42,-214) rotate(${-aR})`}>
          <rect x={-9} y={-6} width={18} height={84} rx={9} fill={top} {...S} />
          <circle cx={0} cy={84} r={11} fill={skin} {...S} />
          {propR ? <g transform="translate(0,84)">{propR}</g> : null}
        </g>
        <rect x={-9} y={-246} width={18} height={22} fill={skin} {...S} />
        {/* মাথা */}
        <g transform={kid ? 'translate(0,-232) scale(1.2) translate(0,232)' : undefined}>
          {orna ? <path d="M-54 -278 Q-58 -340 0 -342 Q58 -340 54 -278 Q58 -214 34 -204 L-34 -204 Q-58 -214 -54 -278Z" fill={orna} {...S} /> : null}
          {hairBack}
          <circle cx={-44} cy={-278} r={8} fill={skin} {...S} />
          <circle cx={44} cy={-278} r={8} fill={skin} {...S} />
          <ellipse cx={0} cy={-278} rx={44} ry={48} fill={skin} {...S} />
          {orna ? (
            <path d="M-46 -276 Q-44 -334 0 -334 Q44 -334 46 -276 Q30 -304 0 -306 Q-30 -304 -46 -276Z" fill={orna} {...S} />
          ) : hairFront}
          {expr !== 'neutral' && expr !== 'worried' && expr !== 'thinking' ? (
            <><circle cx={-29} cy={-262} r={7} fill="#ff8a80" opacity={0.5} /><circle cx={29} cy={-262} r={7} fill="#ff8a80" opacity={0.5} /></>
          ) : null}
          {eyes}
          <g stroke={C.ink} strokeWidth={3.2} strokeLinecap="round">
            <line x1={br[0][0]} y1={br[0][1]} x2={br[0][2]} y2={br[0][3]} />
            <line x1={br[1][0]} y1={br[1][1]} x2={br[1][2]} y2={br[1][3]} />
          </g>
          {glasses ? (
            <g fill="none" stroke={C.ink} strokeWidth={3}>
              <circle cx={-16} cy={-280} r={13} /><circle cx={16} cy={-280} r={13} /><line x1={-3} y1={-280} x2={3} y2={-280} />
            </g>
          ) : null}
          {mouth}
        </g>
      </g>
    </svg>
  );
};

/** কমন প্রপস */
export const Pointer: React.FC = () => (
  <rect x={-3} y={0} width={7} height={150} rx={3} fill="#8d5524" stroke={C.ink} strokeWidth={2} />
);
export const BookProp: React.FC<{color?: string}> = ({color = '#ef5350'}) => (
  <g transform="translate(0,6)">
    <rect x={-24} y={-8} width={48} height={38} rx={4} fill={color} stroke={C.ink} strokeWidth={2.6} />
    <rect x={-19} y={-3} width={9} height={28} fill="#fff" />
  </g>
);
