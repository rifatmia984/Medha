import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {C} from './config';

export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

/** পপ-আপ / স্লাইড এন্ট্রি র‍্যাপার */
export const Pop: React.FC<{
  delay?: number;
  from?: 'scale' | 'up' | 'down' | 'left' | 'right';
  out?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({delay = 0, from = 'scale', out, style, children}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (frame < delay) return <div style={{...style, opacity: 0}}>{children}</div>;
  const s = spring({frame: frame - delay, fps, config: {damping: 12, stiffness: 150, mass: 0.6}});
  const o = out === undefined ? 1 : interpolate(frame, [out, out + 6], [1, 0], clamp);
  const tf =
    from === 'scale' ? `scale(${s})`
    : from === 'up' ? `translateY(${(1 - s) * 70}px)`
    : from === 'down' ? `translateY(${-(1 - s) * 70}px)`
    : from === 'left' ? `translateX(${-(1 - s) * 320}px)`
    : `translateX(${(1 - s) * 320}px)`;
  return <div style={{...style, opacity: Math.min(1, s * 2) * o, transform: tf}}>{children}</div>;
};

/** সিন ট্রানজিশন — রঙিন প্যানেল ডানে সরে যায় */
export const Wipe: React.FC<{color?: string; dur?: number}> = ({color = C.blue, dur = 9}) => {
  const frame = useCurrentFrame();
  if (frame >= dur) return null;
  const p = interpolate(frame, [0, dur], [0, 100]);
  return <AbsoluteFill style={{background: color, transform: `translateX(${p}%)`}} />;
};

export const Pill: React.FC<{bg?: string; color?: string; size?: number; children?: React.ReactNode}> = ({
  bg = C.blue, color = '#fff', size = 40, children,
}) => (
  <div style={{
    background: bg, color, fontSize: size, fontWeight: 700, padding: '8px 34px', borderRadius: 999,
    border: `3px solid ${C.ink}`, whiteSpace: 'nowrap', boxShadow: '0 6px 0 rgba(0,0,0,.18)',
  }}>{children}</div>
);

export const Chip: React.FC<{bg: string; color?: string; size?: number; children?: React.ReactNode}> = ({
  bg, color = '#fff', size = 50, children,
}) => (
  <div style={{
    background: bg, color, fontSize: size, fontWeight: 700, padding: '8px 40px', borderRadius: 22,
    border: `3px solid ${C.ink}`, whiteSpace: 'nowrap', boxShadow: '0 5px 0 rgba(0,0,0,.18)',
  }}>{children}</div>
);

export const Card: React.FC<{style?: React.CSSProperties; children?: React.ReactNode}> = ({style, children}) => (
  <div style={{
    background: '#fff', border: `4px solid ${C.ink}`, borderRadius: 40,
    boxShadow: '0 14px 0 rgba(0,0,0,.14)', boxSizing: 'border-box', ...style,
  }}>{children}</div>
);

/** বোল্ড স্ট্যাম্প (ধপ করে পড়ে) */
export const Stamp: React.FC<{text: string; delay?: number; rot?: number; color?: string; size?: number}> = ({
  text, delay = 0, rot = -7, color = C.red, size = 110,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (frame < delay) return null;
  const s = spring({frame: frame - delay, fps, config: {damping: 9, stiffness: 220, mass: 0.5}});
  const sc = interpolate(s, [0, 1], [2.6, 1]);
  return (
    <div style={{
      transform: `rotate(${rot}deg) scale(${sc})`, opacity: Math.min(1, s * 3), color,
      border: `10px solid ${color}`, borderRadius: 26, padding: '6px 50px', fontSize: size,
      fontWeight: 700, background: 'rgba(255,255,255,.9)', whiteSpace: 'nowrap',
    }}>{text}</div>
  );
};

/** থট বাবল — ডিম্বাকৃতি + ছোট বৃত্তের লেজ */
export const ThoughtBubble: React.FC<{
  x: number; y: number; w: number; h: number; delay?: number;
  tail?: {x: number; y: number; r: number}[]; children?: React.ReactNode;
}> = ({x, y, w, h, delay = 0, tail = [], children}) => (
  <>
    {tail.map((t, i) => (
      <Pop key={i} delay={delay + i * 3} style={{
        position: 'absolute', left: t.x - t.r, top: t.y - t.r, width: t.r * 2, height: t.r * 2,
        borderRadius: '50%', background: '#fff', border: `4px solid ${C.ink}`, boxSizing: 'border-box',
      }} />
    ))}
    <Pop delay={delay + 6} style={{
      position: 'absolute', left: x - w / 2, top: y - h / 2, width: w, height: h, borderRadius: '50%',
      background: '#fff', border: `5px solid ${C.ink}`, boxSizing: 'border-box', display: 'flex',
      alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '0 70px',
    }}>{children}</Pop>
  </>
);

/** নিচের ভাসমান ক্যাপশন (শুধু যখন উপরে কোনো কার্ড/বাবল নেই) */
export type Seg = {t: string; h?: boolean};
export const Caption: React.FC<{segs: Seg[]; from: number; to: number}> = ({segs, from, to}) => {
  const frame = useCurrentFrame();
  if (frame < from || frame > to) return null;
  const a = interpolate(frame, [from, from + 5, to - 4, to], [0, 1, 1, 0], clamp);
  const up = interpolate(frame, [from, from + 5], [40, 0], clamp);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 46, display: 'flex', justifyContent: 'center',
      opacity: a, transform: `translateY(${up}px)`}}>
      <div style={{background: 'rgba(18,40,90,.85)', borderRadius: 30, padding: '12px 48px', fontSize: 70,
        fontWeight: 700, color: '#fff', whiteSpace: 'nowrap', border: '3px solid #fff'}}>
        {segs.map((s, i) => <span key={i} style={{color: s.h ? C.yellow : '#fff'}}>{s.t}</span>)}
      </div>
    </div>
  );
};

/** আইকন (Material paths) */
const PATHS: Record<string, string> = {
  phone: 'M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z',
  bulb: 'M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7z',
  star: 'M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z',
  arrow: 'M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z',
  check: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
  trophy: 'M19 5h-2V3H7v2H5c-1.1 0-2 .9-2 2v1c0 2.55 1.92 4.63 4.39 4.94.63 1.5 1.98 2.63 3.61 2.95V19H7v2h10v-2h-4v-3.11c1.63-.32 2.98-1.45 3.61-2.95C19.08 12.63 21 10.55 21 8V7c0-1.1-.9-2-2-2zM5 8V7h2v3.82C5.84 10.4 5 9.3 5 8zm14 0c0 1.3-.84 2.4-2 2.82V7h2v1z',
  school: 'M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82zM12 3L1 9l11 6 9-4.91V17h2V9L12 3z',
  book: 'M21 5c-1.11-.35-2.33-.5-3.5-.5-1.95 0-4.05.4-5.5 1.5-1.45-1.1-3.55-1.5-5.5-1.5S2.45 4.9 1 6v14.65c0 .25.25.5.5.5.1 0 .15-.05.25-.05C3.1 20.45 5.05 20 6.5 20c1.95 0 4.05.4 5.5 1.5 1.35-.85 3.8-1.5 5.5-1.5 1.65 0 3.35.3 4.75 1.05.1.05.15.05.25.05.25 0 .5-.25.5-.5V6c-.6-.45-1.25-.75-2-1zm0 13.5c-1.1-.35-2.3-.5-3.5-.5-1.7 0-4.15.65-5.5 1.5V8c1.35-.85 3.8-1.5 5.5-1.5 1.2 0 2.4.15 3.5.5v11.5z',
};
export const Icon: React.FC<{name: string; size?: number; color?: string; style?: React.CSSProperties}> = ({
  name, size = 80, color = C.ink, style,
}) => (
  <svg viewBox="0 0 24 24" width={size} height={size} style={style}>
    <path d={PATHS[name]} fill={color} stroke={C.ink} strokeWidth={0.7} strokeLinejoin="round" />
  </svg>
);

/** ভাসমান প্রশ্নবোধক চিহ্ন */
export const QFloat: React.FC<{x: number; y: number; delay: number; size?: number; color?: string}> = ({
  x, y, delay, size = 130, color = C.orange,
}) => {
  const frame = useCurrentFrame();
  return (
    <Pop delay={delay} style={{position: 'absolute', left: x, top: y}}>
      <div style={{fontSize: size, fontWeight: 700, color, WebkitTextStroke: `4px ${C.ink}`,
        transform: `translateY(${Math.sin(frame / 9 + x) * 12}px) rotate(${Math.sin(frame / 14 + y) * 12}deg)`}}>?</div>
    </Pop>
  );
};

/** কনফেটি */
export const Confetti: React.FC = () => {
  const frame = useCurrentFrame();
  const cols = [C.red, C.blue, C.yellow, C.green, C.orange];
  return (
    <AbsoluteFill>
      {Array.from({length: 34}).map((_, i) => {
        const x = Math.abs((Math.sin(i * 12.9898) * 43758.5453) % 1) * 1920;
        const sp = 3 + Math.abs(Math.sin(i * 7.1)) * 4;
        const y = ((frame * sp + i * 97) % 1250) - 100;
        return (
          <div key={i} style={{position: 'absolute', left: x, top: y, width: 16, height: 26, background: cols[i % 5],
            transform: `rotate(${frame * (3 + (i % 5)) + i * 40}deg)`, opacity: 0.85, borderRadius: 3}} />
        );
      })}
    </AbsoluteFill>
  );
};
