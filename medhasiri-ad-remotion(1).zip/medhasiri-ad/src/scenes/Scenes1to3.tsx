import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {C, INFO} from '../config';
import {Character} from '../Character';
import {CleanBg, RoomBg, SchoolBg} from '../Backgrounds';
import {Card, Chip, Icon, Pill, Pop, QFloat, Stamp, ThoughtBubble} from '../ui';

const MOM = {skin: '#e9b48a', hair: '#2b1b12', top: '#2e7d32', bottom: '#1b5e20', orna: '#a5d6a7'};
const KID = {skin: '#eeba92', hair: '#1e1e1e', hairStyle: 'pigtails' as const, top: '#ffffff', bottom: '#1a237e', collar: true, kid: true, bag: '#ef5350'};

/** সিন ১ (০:০০–০:০২.৭) — প্রশ্ন: ভালো স্কুল খুঁজছেন? */
export const Scene1: React.FC = () => (
  <AbsoluteFill>
    <RoomBg />
    <Character x={560} y={1010} scale={2.3} {...MOM} expr="thinking" armR={152} armL={10} seed={1} />
    <Character x={870} y={1010} scale={2.3} {...KID} expr="happy" armL={14} armR={14} seed={3} delay={4} />
    <QFloat x={330} y={230} delay={14} />
    <QFloat x={560} y={110} delay={22} size={110} color={C.blue} />
    <ThoughtBubble x={1340} y={330} w={900} h={380} delay={2}
      tail={[{x: 730, y: 400, r: 14}, {x: 800, y: 375, r: 22}]}>
      <div style={{fontSize: 64, fontWeight: 700, lineHeight: 1.25, color: C.ink}}>
        সন্তানের জন্য <span style={{color: C.orange}}>ভালো স্কুল</span> খুঁজছেন?
      </div>
    </ThoughtBubble>
  </AbsoluteFill>
);

/** সিন ২ (০:০২.৭–০:০৭.৩) — সুখবর! স্কুলের নাম, ভর্তি চলছে */
export const Scene2: React.FC = () => (
  <AbsoluteFill>
    <SchoolBg />
    <Character x={330} y={990} scale={2} {...MOM} expr="excited" armL={150} armR={150} waveL={10} waveR={10} jump seed={1} delay={10} />
    <Character x={640} y={990} scale={2} {...KID} expr="excited" armL={140} armR={140} waveL={12} waveR={12} jump seed={2} delay={14} />
    <Pop delay={10} style={{position: 'absolute', left: 140, top: 90}}>
      <div style={{transform: 'rotate(-6deg)'}}><Pill bg={C.yellow} color={C.ink} size={96}>সুখবর!</Pill></div>
    </Pop>
    <Pop delay={20} from="down" style={{position: 'absolute', left: 740, top: 55, width: 1060}}>
      <Card style={{padding: '18px 30px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8}}>
        <Pill bg={C.orange} size={40}>{INFO.area}</Pill>
        <div style={{fontSize: 84, fontWeight: 700, color: C.navy, lineHeight: 1.15}}>{INFO.schoolName}</div>
      </Card>
    </Pop>
    <div style={{position: 'absolute', left: 940, top: 560}}>
      <Stamp text="ভর্তি চলছে!" delay={99} />
    </div>
  </AbsoluteFill>
);

const Branch: React.FC<{x: number; delay: number; title: string; icon: string; color: string; a: string; b: string}> = ({
  x, delay, title, icon, color, a, b,
}) => (
  <Pop delay={delay} from="up" style={{position: 'absolute', left: x, top: 170, width: 760}}>
    <Card style={{padding: '34px 40px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20, height: 740}}>
      <Pill bg={color} size={62}>{title}</Pill>
      <div style={{width: 190, height: 190, borderRadius: '50%', background: color + '33', border: `4px solid ${C.ink}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        <Icon name={icon} size={120} color={color} />
      </div>
      <Pop delay={delay + 14} from="up"><Chip bg={color} size={52}>{a}</Chip></Pop>
      <Pop delay={delay + 26}><Icon name="arrow" size={80} color={C.ink} style={{transform: 'rotate(90deg)'}} /></Pop>
      <Pop delay={delay + 36} from="up"><Chip bg={color} size={52}>{b}</Chip></Pop>
    </Card>
  </Pop>
);

/** সিন ৩ (০:০৭.৩–০:১৪.২) — দুই শাখার তুলনা */
export const Scene3: React.FC = () => (
  <AbsoluteFill>
    <CleanBg />
    <Branch x={130} delay={10} title="স্কুল শাখা" icon="school" color={C.blue} a="প্লে গ্রুপ" b="পঞ্চম শ্রেণি" />
    <Pop delay={92} style={{position: 'absolute', left: 900, top: 470}}>
      <div style={{width: 120, height: 120, borderRadius: '50%', background: C.yellow, border: `4px solid ${C.ink}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 80, fontWeight: 700}}>+</div>
    </Pop>
    <Branch x={1030} delay={95} title="কোচিং শাখা" icon="book" color={C.orange} a="ষষ্ঠ শ্রেণি" b="দশম শ্রেণি" />
  </AbsoluteFill>
);
