import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {C, INFO, fmtPhone, toBn} from '../config';
import {BookProp, Character, Pointer} from '../Character';
import {ClassBg, CleanBg} from '../Backgrounds';
import {Caption, Card, Confetti, Icon, Pill, Pop, clamp} from '../ui';

const Mini: React.FC<{v: number; label: string; bg: string; color: string}> = ({v, label, bg, color}) => (
  <div style={{background: bg, border: `4px solid ${C.ink}`, borderRadius: 28, padding: '14px 24px', width: 330, textAlign: 'center'}}>
    <div style={{fontSize: 100, fontWeight: 700, color, lineHeight: 1.1}}>
      {toBn(v)}<span style={{fontSize: 46}}> জন</span>
    </div>
    <div style={{fontSize: 46, fontWeight: 700, color: C.ink}}>{label}</div>
  </div>
);

/** সিন ৪ (০:১৪.২–০:২২.০) — বৃত্তি পরীক্ষা ফলাফল */
export const Scene4: React.FC = () => {
  const frame = useCurrentFrame();
  const n = Math.round(interpolate(frame, [72, 100], [0, INFO.total], clamp));
  return (
    <AbsoluteFill>
      <CleanBg c1="#fff8e1" c2="#ffe0a3" />
      <Confetti />
      <Character x={270} y={1000} scale={2.1} skin="#d9a47a" hair="#1c1c1c" top="#64b5f6" bottom="#37474f"
        collar tie="#c62828" glasses expr="proud" armL={140} armR={140} waveL={8} waveR={8} seed={4} delay={10} />
      <Character x={560} y={1000} scale={2.1} kid medal skin="#eeba92" hair="#1e1e1e" hairStyle="pigtails" top="#fff"
        bottom="#1a237e" collar expr="excited" armL={130} armR={130} waveL={10} waveR={10} jump seed={1} delay={16} />
      <Character x={760} y={1000} scale={2.1} kid medal skin="#e2a97e" hair="#222" top="#fff" bottom="#1a237e"
        collar expr="excited" armL={130} armR={130} waveL={10} waveR={10} jump seed={2} delay={22} />
      <Character x={950} y={1000} scale={2.1} kid medal skin="#f0c09a" hair="#3e2723" hairStyle="bun" top="#fff"
        bottom="#1a237e" collar expr="happy" armL={125} armR={125} waveL={10} waveR={10} jump seed={3} delay={28} />
      <Pop delay={10} from="right" style={{position: 'absolute', left: 1030, top: 110, width: 800}}>
        <Card style={{padding: '30px 36px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 20}}>
            <Icon name="trophy" size={110} color={C.yellow} />
            <Pill bg={C.blue} size={52}>বৃত্তি পরীক্ষা {INFO.year}</Pill>
          </div>
          <Pop delay={72}>
            <div style={{display: 'flex', alignItems: 'baseline', gap: 16}}>
              <span style={{fontSize: 190, fontWeight: 700, color: C.orange, lineHeight: 1}}>{toBn(n)}</span>
              <span style={{fontSize: 58, fontWeight: 700, color: C.ink}}>জন কৃতি শিক্ষার্থী</span>
            </div>
          </Pop>
          <div style={{display: 'flex', gap: 26}}>
            <Pop delay={135}><Mini v={INFO.talent} label="ট্যালেন্টপুলে" bg="#e3f2fd" color={C.blue} /></Pop>
            <Pop delay={180}><Mini v={INFO.general} label="সাধারণে" bg="#e8f5e9" color={C.green} /></Pop>
          </div>
        </Card>
      </Pop>
    </AbsoluteFill>
  );
};

/** সিন ৫ (০:২২.০–০:২৫.৬) — ৫ম ও ৮ম শ্রেণির বৃত্তি প্রস্তুতি কোচিং */
export const Scene5: React.FC = () => {
  const box: React.CSSProperties = {border: '6px dashed #fff', borderRadius: 24, padding: '6px 50px', fontSize: 150, color: '#fff', fontWeight: 700};
  return (
    <AbsoluteFill>
      <ClassBg />
      <Pop delay={14} style={{position: 'absolute', left: 650, top: 215}}><div style={box}>৫ম</div></Pop>
      <Pop delay={32} style={{position: 'absolute', left: 1050, top: 215}}><div style={box}>৮ম</div></Pop>
      {[70, 78, 86].map((d, i) => (
        <Pop key={d} delay={d} style={{position: 'absolute', left: 900 + i * 110, top: 470}}>
          <Icon name="star" size={100} color={C.yellow} />
        </Pop>
      ))}
      <Character x={330} y={970} scale={2} skin="#d9a47a" hair="#1c1c1c" top="#64b5f6" bottom="#37474f"
        collar tie="#c62828" glasses expr="happy" armR={104} armL={10} propR={<Pointer />} seed={4} />
      <Character x={1700} y={970} scale={2} kid skin="#e2a97e" hair="#222" top="#fff" bottom="#1a237e"
        collar expr="happy" armL={45} armR={10} propL={<BookProp />} seed={2} delay={8} />
      <Caption from={4} to={54} segs={[{t: 'পঞ্চম ও অষ্টম', h: true}, {t: ' শ্রেণির জন্য'}]} />
      <Caption from={54} to={106} segs={[{t: 'স্পেশাল '}, {t: 'বৃত্তি প্রস্তুতি', h: true}, {t: ' কোচিং'}]} />
    </AbsoluteFill>
  );
};

const Digits: React.FC<{text: string; start: number; dur: number}> = ({text, start, dur}) => {
  const frame = useCurrentFrame();
  const vis = Math.floor(interpolate(frame, [start, start + dur - 6], [0, text.length + 1], clamp));
  return (
    <span>{text.split('').map((ch, i) => <span key={i} style={{opacity: i < vis ? 1 : 0.15}}>{ch}</span>)}</span>
  );
};

const PhoneCard: React.FC<{top: number; delay: number; num: string; start: number; dur: number}> = ({top, delay, num, start, dur}) => (
  <Pop delay={delay} from="right" style={{position: 'absolute', left: 700, top, width: 1120}}>
    <Card style={{padding: '24px 40px', display: 'flex', alignItems: 'center', gap: 30}}>
      <Icon name="phone" size={90} color={C.blue} />
      <div style={{fontSize: 120, fontWeight: 700, color: C.navy, letterSpacing: 6, whiteSpace: 'nowrap'}}>
        <Digits text={fmtPhone(num)} start={start} dur={dur} />
      </div>
    </Card>
  </Pop>
);

/** সিন ৬ (০:২৫.৬–০:৩৮.৬) — যোগাযোগ */
export const Scene6: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill>
      <CleanBg c1="#2a4a9c" c2="#12285a" />
      <Pop delay={10} from="down" style={{position: 'absolute', left: 0, right: 0, top: 80, textAlign: 'center'}}>
        <span style={{fontSize: 84, fontWeight: 700, color: '#fff'}}>
          বিস্তারিত জানতে <span style={{color: C.yellow}}>যোগাযোগ</span> করুন
        </span>
      </Pop>
      <Pop delay={12} style={{position: 'absolute', left: 160, top: 340, width: 400, height: 400}}>
        {[0, 1, 2].map((i) => {
          const t = ((frame + i * 20) % 60) / 60;
          return <div key={i} style={{position: 'absolute', inset: 0, borderRadius: '50%', border: '6px solid rgba(255,255,255,.7)',
            transform: `scale(${0.7 + t * 0.8})`, opacity: 1 - t}} />;
        })}
        <div style={{position: 'absolute', inset: 60, borderRadius: '50%', background: C.orange, border: `6px solid ${C.ink}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `rotate(${Math.sin(frame * 1.1) * 9}deg)`}}>
          <Icon name="phone" size={150} color="#fff" />
        </div>
      </Pop>
      <PhoneCard top={300} delay={76} num={INFO.phone1} start={79} dur={132} />
      <Pop delay={209} style={{position: 'absolute', left: 700, width: 1120, top: 550, display: 'flex', justifyContent: 'center'}}>
        <Pill bg={C.orange} size={58}>অথবা</Pill>
      </Pop>
      <PhoneCard top={690} delay={246} num={INFO.phone2} start={251} dur={125} />
    </AbsoluteFill>
  );
};

/** সিন ৭ (০:৩৮.৬–০:৪১.৮) — স্লোগান */
export const Scene7: React.FC = () => {
  const frame = useCurrentFrame();
  const glow = 1 + Math.sin(frame / 6) * 0.08;
  return (
    <AbsoluteFill>
      <CleanBg c1="#fff3c4" c2="#ffcf5c" />
      <Pop delay={4} style={{position: 'absolute', left: 840, top: 60, width: 240, height: 240}}>
        <div style={{position: 'absolute', inset: -40, borderRadius: '50%', background: 'rgba(255,255,255,.7)', transform: `scale(${glow})`}} />
        <Icon name="bulb" size={240} color={C.yellow} style={{position: 'absolute', left: 0, top: 0}} />
      </Pop>
      {[[640, 130, 10], [1190, 110, 16], [1290, 250, 22], [540, 270, 28]].map(([x, y, d], i) => (
        <Pop key={i} delay={d} style={{position: 'absolute', left: x, top: y}}>
          <Icon name="star" size={90} color={C.orange} style={{transform: `rotate(${Math.sin(frame / 10 + i) * 18}deg)`}} />
        </Pop>
      ))}
      <Pop delay={12} from="up" style={{position: 'absolute', left: 210, top: 380, width: 1500}}>
        <Card style={{padding: '50px 60px', textAlign: 'center', fontSize: 100, fontWeight: 700, lineHeight: 1.3, color: C.navy}}>
          সৃজনশীল <span style={{color: C.orange}}>মেধা বিকাশই</span> আমাদের লক্ষ্য
        </Card>
      </Pop>
      <Pop delay={50} from="up" style={{position: 'absolute', left: 0, right: 0, top: 830, display: 'flex', justifyContent: 'center'}}>
        <Pill bg={C.navy} size={54}>{INFO.schoolName} · {INFO.area}</Pill>
      </Pop>
    </AbsoluteFill>
  );
};
