import React from 'react';
import {AbsoluteFill} from 'remotion';
import {C} from './config';

const Svg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill>
    <svg width="100%" height="100%" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid slice">{children}</svg>
  </AbsoluteFill>
);
const S = {stroke: C.ink, strokeWidth: 5, strokeLinejoin: 'round' as const};

/** ঘর: জানালা + সোফা + গাছ + মেঝে */
export const RoomBg: React.FC = () => (
  <Svg>
    <defs>
      <linearGradient id="rw" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#ffeccc" /><stop offset="1" stopColor="#ffd8a6" />
      </linearGradient>
    </defs>
    <rect width="1920" height="1080" fill="url(#rw)" />
    <rect y="880" width="1920" height="200" fill="#c98b57" />
    <rect y="868" width="1920" height="16" fill="#a8693a" />
    <rect x="110" y="130" width="330" height="360" rx="14" fill="#bfe6ff" {...S} />
    <circle cx="220" cy="230" r="42" fill="#ffd54a" stroke={C.ink} strokeWidth="4" />
    <path d="M113 487 L113 430 L230 350 L330 415 L437 345 L437 487Z" fill="#8bc34a" />
    <line x1="275" y1="130" x2="275" y2="490" {...S} />
    <line x1="110" y1="310" x2="440" y2="310" {...S} />
    <rect x="1260" y="660" width="560" height="220" rx="40" fill="#7e57c2" {...S} />
    <rect x="1230" y="740" width="90" height="140" rx="30" fill="#6a45b0" {...S} />
    <rect x="1760" y="740" width="90" height="140" rx="30" fill="#6a45b0" {...S} />
    <rect x="1300" y="720" width="460" height="110" rx="26" fill="#9575cd" {...S} />
    <path d="M1120 880 L1140 790 L1210 790 L1230 880Z" fill="#ef6c00" {...S} />
    <ellipse cx="1140" cy="735" rx="26" ry="64" fill="#43a047" transform="rotate(-25 1140 735)" {...S} />
    <ellipse cx="1210" cy="735" rx="26" ry="64" fill="#43a047" transform="rotate(25 1210 735)" {...S} />
    <ellipse cx="1175" cy="720" rx="26" ry="72" fill="#66bb6a" {...S} />
  </Svg>
);

/** স্কুলের সামনের দৃশ্য: আকাশ + ভবন + গাছ + মাঠ */
export const SchoolBg: React.FC = () => (
  <Svg>
    <defs>
      <linearGradient id="sk" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#7fd0ff" /><stop offset="1" stopColor="#e9f8ff" />
      </linearGradient>
    </defs>
    <rect width="1920" height="1080" fill="url(#sk)" />
    <circle cx="170" cy="170" r="70" fill="#ffd54a" stroke={C.ink} strokeWidth="4" />
    <g fill="#fff" stroke={C.ink} strokeWidth="4">
      <ellipse cx="520" cy="190" rx="110" ry="44" /><ellipse cx="610" cy="170" rx="70" ry="40" />
      <ellipse cx="1560" cy="120" rx="110" ry="42" /><ellipse cx="1650" cy="105" rx="64" ry="36" />
    </g>
    <rect y="830" width="1920" height="250" fill="#7cc576" />
    <path d="M0 1010 Q960 950 1920 1010 L1920 1080 L0 1080Z" fill="#69b565" />
    <rect x="800" y="400" width="940" height="440" fill="#ffb35c" {...S} />
    <path d="M770 405 L1270 285 L1770 405Z" fill="#c0562b" {...S} />
    <line x1="1270" y1="285" x2="1270" y2="190" {...S} />
    <path d="M1270 190 L1350 215 L1270 240Z" fill={C.red} {...S} />
    {[850, 990, 1480, 1610].map((x) => (
      <React.Fragment key={x}>
        <rect x={x} y="450" width="110" height="120" rx="10" fill="#bfe6ff" {...S} />
        <rect x={x} y="640" width="110" height="120" rx="10" fill="#bfe6ff" {...S} />
      </React.Fragment>
    ))}
    <rect x="1195" y="610" width="150" height="230" rx="12" fill="#6d4c41" {...S} />
    <rect x="1160" y="830" width="220" height="30" fill="#bdbdbd" {...S} />
    <rect x="70" y="700" width="46" height="170" fill="#8d5524" {...S} />
    <circle cx="95" cy="640" r="115" fill="#43a047" {...S} />
  </Svg>
);

/** ক্লাসরুম: ব্ল্যাকবোর্ড + ঘড়ি + পোস্টার */
export const ClassBg: React.FC = () => (
  <Svg>
    <rect width="1920" height="1080" fill="#e7f3e0" />
    <rect y="870" width="1920" height="210" fill="#d9b98c" />
    <rect y="858" width="1920" height="14" fill="#a8803f" />
    <rect x="520" y="150" width="1060" height="480" rx="14" fill="#2f5d50" stroke="#8d5524" strokeWidth="16" />
    <rect x="520" y="632" width="1060" height="18" fill="#8d5524" {...S} />
    <circle cx="1740" cy="190" r="72" fill="#fff" {...S} />
    <line x1="1740" y1="190" x2="1740" y2="140" {...S} />
    <line x1="1740" y1="190" x2="1778" y2="205" {...S} />
    <rect x="100" y="150" width="210" height="170" rx="10" fill="#fff59d" {...S} />
    <path d="M140 280 L200 190 L250 250 L280 215" fill="none" stroke="#e65100" strokeWidth="8" strokeLinecap="round" />
  </Svg>
);

/** ক্লিন ভিনিয়েট ব্যাকগ্রাউন্ড (মোশন গ্রাফিক্স সিন) */
export const CleanBg: React.FC<{c1?: string; c2?: string}> = ({c1 = '#e3f2fd', c2 = '#90caf9'}) => (
  <AbsoluteFill style={{background: `radial-gradient(ellipse at center, ${c1} 0%, ${c2} 100%)`}}>
    {[[-120, -120, 420], [1600, 760, 480], [1500, -160, 300], [-100, 800, 340]].map(([x, y, s], i) => (
      <div key={i} style={{position: 'absolute', left: x, top: y, width: s, height: s, borderRadius: '50%',
        background: 'rgba(255,255,255,.22)'}} />
    ))}
  </AbsoluteFill>
);
